import './style.css';
import ScrollIndicator from './scrollIndicator';
const main = () => {
  const indicator = new ScrollIndicator();
  console.log(indicator);
};

main();
